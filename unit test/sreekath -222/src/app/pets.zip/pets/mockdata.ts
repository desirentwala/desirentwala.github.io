
   export class mockData{
        "data": 
            {
                "id": 5,
                "userId": 5,
                "petName": "Max",
                "speciesId": 1,
                "practiceId": 2,
                "breed": "Breed1",
                "gender": "Male",
                "dob": "2015-01-01",
                "profilePic": "PE_6.jpg",
                "neutered": false,
                "deceased": false,
                "hide": false,
                "active": true,
                "insured": null,
                "insurenceProvider": null,
                "createdOn": "2019-12-18T22:46:39.000Z",
                "updatedOn": null
            }
   }
   
 
