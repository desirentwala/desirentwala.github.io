export class MockStorage{
    
}