export const environment = {
  production: true,
  baseUri: 'http://13.234.214.144:3001/'
};
