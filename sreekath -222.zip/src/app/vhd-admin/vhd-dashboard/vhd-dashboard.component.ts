import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vhd-dashboard',
  templateUrl: './vhd-dashboard.component.html',
  styleUrls: ['./vhd-dashboard.component.scss'],
})
export class VhdDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
