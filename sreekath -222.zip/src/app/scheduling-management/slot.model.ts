export class Slot {
    id?: number;
    userId: number;
    practiceId: number;
    startsAt: any;
    duration: number;
    isPrivate: boolean;
    practiceAppointmentTypeId?: any;
    appointmentType?: any;
}
