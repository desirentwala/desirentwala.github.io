export class Practice {
    id?: number;
    practiceName: string;
    phoneNo: string;
    website: string;
    logo: string;
    species: Array<any>;
}
