export class Captcha {
  captcha: string;
  value: string;
}
