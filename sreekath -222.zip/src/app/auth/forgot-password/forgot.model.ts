export class ForgotPassword {
  email: string;
}
