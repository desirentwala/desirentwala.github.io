export class MockService
{
    data:
[
{
    "message":"Registerd succesfull"
   },
{
    "message":" User with email already exists!"},
{
     "message":  "User with mobile already exists!"
},
{
      "message":"Something went erong, please try again!"
},
{
      "message":"Failed to create user, please try again!"
},
{
       "message":"Please verify the OTP, for Profile activation !",
}
]
}


