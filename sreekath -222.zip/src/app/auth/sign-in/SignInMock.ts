export class SignInMock
{
 data:
[
{
    "message":"Login success!"
   },
{
    "message":"Invalid E-mailId or Password !"},
{
     "message":  "User with mobile already exists!"
},
{
      "message":"Please verify the OTP, for Profile activation !"
},
{
      "message":"Invalid credentials or status is not valid!"
},
{
       "message":"Failed to Authenticate, please try again!",
}
]
}