export class SignIn {
    email: string;
    password: string;
    isChecked: boolean;
}
