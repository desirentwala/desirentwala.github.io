

export class OtpVerification{
    Otp: Number;
    otpOutput = [];
}