export class UserRole {
    id?: number;
    userId: number;
    roleId: number;
}