
    export const Pages = [
       {
         title: "Dashboard",
         path: 'pets',
         icon: "arrow-dropright-circle"
       },
       {
         title: "Pets",
         path: 'pets/list',
         icon: "home"
       },
       {
         title: "Bookings",
        // path: 'online-consultation',
         icon: "bookmark"
       },
       {
         title: "Payments",
       //  path: 'pets',
         icon: "cash"
       },
       {
         title: "Invoices",
        // path: 'pets',
         icon: "cash"
       }
     ];