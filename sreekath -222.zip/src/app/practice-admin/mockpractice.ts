export class mockPracticeData{
"data":[
    {"id":49,
    "startsAt":"2019-12-27T09:30:00.000Z",
    "duration":20,
    "isPrivate":0,
    "vet":"Chetan KV"
   }]
}