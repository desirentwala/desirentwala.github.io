// import { async, ComponentFixture, TestBed } from '@angular/core/testing';
// import { IonicModule } from '@ionic/angular';

// import { BaseRoutePage } from './base-route.page';

// describe('BaseRoutePage', () => {
//   let component: BaseRoutePage;
//   let fixture: ComponentFixture<BaseRoutePage>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ BaseRoutePage ],
//       imports: [IonicModule.forRoot()]
//     }).compileComponents();

//     fixture = TestBed.createComponent(BaseRoutePage);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   }));

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
