export class Vet {
vetName: string;
phoneNumber: string;
email: string;
species: string;
}
