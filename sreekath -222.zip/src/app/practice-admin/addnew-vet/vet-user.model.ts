export class Vet {
    id?: number;
    firstName: string;
    mobile: string;
    email: string = '';
    code = '';
    species = [];
    contact: string;
    practiceId: number;
    isActive?: boolean;
    password?: string;
    userName?: any;
    prefix?: any;
}
