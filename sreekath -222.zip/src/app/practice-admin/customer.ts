export class Customer {
    id?: number;
    email: string;
    petName: string;
    value: string;
    fullName: string;
    mobile: string;
    password: string;
    practiceId: number;
}
