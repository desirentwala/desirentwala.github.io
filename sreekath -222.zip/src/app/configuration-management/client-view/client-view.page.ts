import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-client-view',
  templateUrl: './client-view.page.html',
  styleUrls: ['./client-view.page.scss'],
})
export class ClientViewPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
