/**
 * This barrel file provides the exports for the Core of NCP which will behave as framework(services, components).
*/

export * from './ncpapp.component';
export * from './ncpapp.routes';
export * from './ncpapp.core.module';