/**
 * This barrel file provides the exports for all ui components).
*/

export * from './contact.component';
export * from './ncpcontact.component';