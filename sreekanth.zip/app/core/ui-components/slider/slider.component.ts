import { NgModule, Component, ElementRef, AfterViewInit, OnDestroy, Input, Output, SimpleChange, EventEmitter, forwardRef, Renderer } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DomHandler } from '../dom/domhandler';
import { NG_VALUE_ACCESSOR, ControlValueAccessor } from '@angular/forms';
import { TooltipModule } from '../tooltip/index';
import { UiButtonModule } from '../button/index';

export const SLIDER_VALUE_ACCESSOR: any = {
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => Slider),
    multi: true
};

@Component({
    selector: 'slider',
    templateUrl: 'slider.html',
    providers: [SLIDER_VALUE_ACCESSOR, DomHandler]
})
export class Slider implements AfterViewInit, OnDestroy, ControlValueAccessor {

    @Input() animate: boolean ;

    @Input() readOnly: boolean;

    @Input() min: number = 0;

    @Input() max: number = 100;

    @Input() orientation: string = 'horizontal';

    @Input() step: number;

    @Input() range: boolean;

    @Input() style: any;

    @Input() styleClass: string;

    @Input() sliderClass: string = '';

    @Input() customFlag: boolean = false;

    @Input() hasTooltip: boolean = false;

    @Input() tooltipPlacement: string = 'top';

    @Input() mandatoryFlag: boolean = false;
    
    @Input() elementLabel: string;

    @Output() onChange: EventEmitter<any> = new EventEmitter();

    @Output() onSlideEnd: EventEmitter<any> = new EventEmitter();

    public value: number;

    public values: number;

    public handleValue: number;

    public handleValues: number[] = [];

    public onModelChange: Function = () => { };

    public onModelTouched: Function = () => { };

    public dragging: boolean;

    public dragListener: any;

    public mouseupListener: any;

    public initX: number;

    public initY: number;

    public barWidth: number;

    public barHeight: number;

    public sliderHandleClick: boolean;

    public handleIndex: number;

    constructor(public el: ElementRef, public domHandler: DomHandler, public renderer: Renderer) { }

    onMouseDown(event: Event, index?: number) {
        if (this.readOnly) {
            return;
        }

        this.dragging = true;
        this.updateDomData();
        this.sliderHandleClick = true;
        this.handleIndex = index;
    }

    onBarClick(event) {
        if (this.readOnly) {
            return;
        }

        if (!this.sliderHandleClick) {
            this.updateDomData();
            this.handleChange(event);
        }

        this.sliderHandleClick = false;
    }

    ngAfterViewInit() {
        if (this.readOnly) {
            return;
        }

        this.dragListener = this.renderer.listenGlobal('document', 'mousemove', (event) => {
            if (this.dragging) {
                this.handleChange(event);
            }
        });

        this.mouseupListener = this.renderer.listenGlobal('document', 'mouseup', (event) => {
            if (this.dragging) {
                this.dragging = false;
                this.onSlideEnd.emit({ originalEvent: event, value: this.value });
            }
        });
    }

    handleChange(event: Event) {
        let handleValue = this.calculateHandleValue(event);
        let newValue = this.getValueFromHandle(handleValue);

        if (this.range) {
            if (this.step) {
                this.handleStepChange(newValue, this.values[this.handleIndex]);
            }
            else {
                this.handleValues[this.handleIndex] = handleValue;
                this.updateValue(newValue, event);
            }
        }
        else {
            if (this.step) {
                this.handleStepChange(newValue, this.value);
            }
            else {
                this.handleValue = handleValue;
                this.updateValue(newValue, event);
            }
        }
    }

    handleStepChange(newValue: number, oldValue: number) {
        let diff = (newValue - oldValue);

        if (diff < 0 && (-1 * diff) >= this.step / 2) {
            newValue = oldValue - this.step;
            this.updateValue(newValue);
            this.updateHandleValue();
        }
        else if (diff > 0 && diff >= this.step / 2) {
            newValue = oldValue + this.step;
            this.updateValue(newValue);
            this.updateHandleValue();
        }
    }

    writeValue(value: any): void {
        if (this.range)
            this.values = value || [0, 0];
        else
            this.value = value || 0;

        this.updateHandleValue();
    }

    registerOnChange(fn: Function): void {
        this.onModelChange = fn;
    }

    registerOnTouched(fn: Function): void {
        this.onModelTouched = fn;
    }

    setDisabledState(val: boolean): void {
        this.readOnly = val;
    }

    updateDomData(): void {
        let rect = this.el.nativeElement.children[0].getBoundingClientRect();
        this.initX = rect.left + this.domHandler.getWindowScrollLeft();
        this.initY = rect.top + this.domHandler.getWindowScrollTop();
        this.barWidth = this.el.nativeElement.children[0].offsetWidth;
        this.barHeight = this.el.nativeElement.children[0].offsetHeight;
    }

    calculateHandleValue(event): number {
        if (this.orientation === 'horizontal')
            return Math.floor(((event.pageX - this.initX) * 100) / (this.barWidth));
        else
            return Math.floor((((this.initY + this.barHeight) - event.pageY) * 100) / (this.barHeight));
    }

    updateHandleValue(): void {
        if (this.range) {
            this.handleValues[0] = (this.values[0] < this.min ? 0 : this.values[0] - this.min) * 100 / (this.max - this.min);
            this.handleValues[1] = (this.values[1] > this.max ? 100 : this.values[1] - this.min) * 100 / (this.max - this.min);
        }
        else {
            if (this.value < this.min)
                this.handleValue = 0;
            else if (this.value > this.max)
                this.handleValue = 100;
            else
                this.handleValue = (this.value - this.min) * 100 / (this.max - this.min);
        }
    }

    updateValue(val: number, event?: Event): void {
        if (this.range) {
            let value = val;

            if (this.handleIndex == 0) {
                if (value < this.min) {
                    value = this.min;
                    this.handleValues[0] = 0;
                }
                else if (value > this.values[1]) {
                    value = this.values[1];
                    this.handleValues[0] = this.handleValues[1];
                }
            }
            else {
                if (value > this.max) {
                    value = this.max;
                    this.handleValues[1] = 100;
                }
                else if (value < this.values[0]) {
                    value = this.values[0];
                    this.handleValues[1] = this.handleValues[0];
                }
            }

            this.values[this.handleIndex] = Math.floor(value);
            this.onModelChange(this.values);
            this.onChange.emit({ event: event, values: this.values });
        }
        else {
            if (val < this.min) {
                val = this.min;
                this.handleValue = 0;
            }
            else if (val > this.max) {
                val = this.max;
                this.handleValue = 100;
            }

            this.value = Math.floor(val);
            this.onModelChange(this.value);
            this.onChange.emit({ event: event, value: this.value });
        }
    }

    getValueFromHandle(handleValue: number): number {
        return (this.max - this.min) * (handleValue / 100) + this.min;
    }

    ngOnDestroy() {
        if (this.dragListener) {
            this.dragListener();
        }

        if (this.mouseupListener) {
            this.mouseupListener();
        }
    }
}

@NgModule({
    imports: [CommonModule, TooltipModule, UiButtonModule],
    exports: [Slider],
    declarations: [Slider]
})
export class SliderModule { }