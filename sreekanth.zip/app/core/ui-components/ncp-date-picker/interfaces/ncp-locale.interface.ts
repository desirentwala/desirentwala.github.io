import {IMyOptions} from './ncp-options.interface';

export interface IMyLocales {
    [lang: string]: IMyOptions;
}