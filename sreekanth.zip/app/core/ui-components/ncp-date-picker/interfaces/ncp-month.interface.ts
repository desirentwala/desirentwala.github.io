export interface IMyMonth {
    monthTxt: string;
    monthNbr: number;
    yearTxt: string,
    year: number;
}