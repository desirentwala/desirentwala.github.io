export interface IMyDatesLabels {
    [date: string]: string;
}