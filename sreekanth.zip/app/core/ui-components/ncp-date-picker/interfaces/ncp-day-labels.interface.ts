export interface IMyDayLabels {
    [day: string]: string;
}