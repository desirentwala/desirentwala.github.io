export class NonGregorianTypes {
    public static PERSIAN = 'PER'
}