/**
 * This barrel file provides the exports for all ui components).
*/

export * from './ncp-calendar.module';