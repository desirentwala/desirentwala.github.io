/**
 * This barrel file provides the exports for all ui components).
*/

export * from './coveragedisplay.component';