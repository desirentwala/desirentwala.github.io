
export interface IModel{
}