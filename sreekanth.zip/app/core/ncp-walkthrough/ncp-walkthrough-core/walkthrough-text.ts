export class WalkthroughText {
    previous ?= 'Previous';
    next ?= 'Next';
    close ?= 'Close';
}
