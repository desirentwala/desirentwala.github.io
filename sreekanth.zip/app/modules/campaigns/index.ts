/**
 * This barrel file provides the export for the shared campaigns Component.
 */
export * from './campaigns.module';
