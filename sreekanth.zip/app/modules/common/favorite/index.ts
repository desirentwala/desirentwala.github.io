/**
 * This barrel file provides the export for the shared Dashboard Component.
 */
export * from './favorite';
