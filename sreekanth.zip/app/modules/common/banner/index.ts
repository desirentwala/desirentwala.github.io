import { BannerService } from './services/banner.service';
export * from './banner.component';
export * from './services/banner.service';
const BANNER_PROVIDERS = [BannerService];
export {
    BANNER_PROVIDERS
};