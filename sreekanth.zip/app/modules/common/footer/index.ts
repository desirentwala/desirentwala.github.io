/**
 * This barrel file provides the export for the shared NavbarComponent.
 */
export * from './footer';
export * from './footerLogo/footerLogo';
export * from './map/map';
export * from './footerContact/footerContact';