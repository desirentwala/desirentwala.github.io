// tslint:disable-next-line:eofline
export * from './faq.compontent';